**************
Setup
**************

Welcome in the setup section, here you will find the installation guides for the different parts of RADii as well as technical information about necessary hardware and infrastructure.

.. @gereon ich würde das mit dem login und radii account 1x hier hintun. dann musst du im gh und viewer nicht mehr drauf verweisen.

Setup Pages:
-----------------

.. toctree::
	:titlesonly:
	:numbered:

	2_install_PC
	3_install_grasshopper
	4_install_occulus
	5_install_Technical_Prereq
	6_install_teaching
