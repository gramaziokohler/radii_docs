_________________________________
Setup RADii Standard Viewers
_________________________________


.. image:: ../Setup/Images/Radii_Info_Downloads_Standard_viewer.png

1. **Download** the latest Radii Viewer for your platform from https://RADii.info/
2. **Register** in the user panel **and confirm** your email (it is not necessary to set a domain name)
3. **Install** the file
4. **Start** RADii Viewer

.. image:: ../Setup/Images/Menu_connect_blank.png
    

    

**Congratulations** you have installed Radii. On how to use Radii consult the Quick Guide and the Viewer documentation