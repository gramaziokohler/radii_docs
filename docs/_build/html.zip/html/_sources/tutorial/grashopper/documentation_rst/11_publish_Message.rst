.. RevSarah

****************
PublishMessage
****************


.. image:: ../images/Publish/Publish_message.png

.. topic:: Definition

  This component is used to publish temporary messages of up to 64 characters to a channel.

  .. @gereon_ maybe it could  be added that the messages disappear automatically after ??? and is limited to max. 64 characters

Input
---------

.. table::
  :align: left

  ==========  ======================================  ==============
  Name        Description                             Type
  ==========  ======================================  ==============
  Connection  Link with the Connect component         Connection
  ==========  ======================================  ==============

Right click menu
-----------------

.. table::
  :align: left
    
  ======================= ========================================================================
  Send Massage to channel Type a message and press enter to send all viewers that are connected
  ======================= ========================================================================

