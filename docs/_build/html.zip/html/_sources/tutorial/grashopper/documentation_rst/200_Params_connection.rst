****************************
Params Connect
****************************


.. image:: ../images/Params/Params_connect.png
    :scale: 60%

.. topic:: Definition
  
  This component is a relay for connections that lets you organize your wires more efficiently.


Input
---------

.. table::
  :align: left
    
  ==========  ======================================  ==============
  Name        Description                             Type
  ==========  ======================================  ==============
  Connection  Link with the Connect component         Connection
  ==========  ======================================  ==============

Output
------------

.. table::
  :align: left
    
  ==========  ======================================  ==============
  Name        Description                             Type
  ==========  ======================================  ==============
  Connection  Link with the Connect component         Connection
  ==========  ======================================  ==============

