***************
Params Content
***************

.. image:: ../images/Params/Params_content.png
    :scale: 60%

.. topic:: Definition
  
  This component is a relay for content that lets you organize your wires more efficiently.


Input
---------

.. table::
  :align: left
    
  ==========  ======================================  ==============
  Name        Description                             Type
  ==========  ======================================  ==============
  Content     Link content in and outputs             RADii Content
  ==========  ======================================  ==============

Output
------------

.. table::
  :align: left
    
  ==========  ======================================  ==============
  Name        Description                             Type
  ==========  ======================================  ==============
  Content     Link content in and outputs             RADii Content
  ==========  ======================================  ==============